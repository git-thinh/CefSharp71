#!/usr/bin/env bash
docker run -it -p 5000:5000 --rm kestrel-http2-sample
